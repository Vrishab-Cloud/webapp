const { Router } = require("express");

const router = Router();
const { user, unhandledCase } = require("../controllers");
const { basicAuth, notAuth } = require("../middlewares/user");
const {
  blockQueryParam,
  dbErrorHandler,
  blockPayload,
} = require("../middlewares");

router.use(blockQueryParam);

router.all("/", notAuth);
router.all("/self", basicAuth);

router.route("/").post(user.post).head(unhandledCase).all(unhandledCase);

router
  .route("/self")
  .get(blockPayload, user.get)
  .put(user.put)
  .head(unhandledCase)
  .all(unhandledCase);

router.use(dbErrorHandler);

module.exports = router;
